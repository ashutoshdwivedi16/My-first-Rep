package com.spglobal.ratings.rap;

import java.io.File;

public final class RestCreatorConstants {

	private RestCreatorConstants() {
	};

	public static final String TEMPLATE_DEST_FILE_PATH = "destFilePath";
	public static final String MODEL_MAIN_HEADER_KEY = "modelMainHeder";
	public static final String MODEL_MAIN_FUNCTION_KEY = "modelMainFunction";
	public static final String INCLUDE_KEY = "#include";
	public static final String HEADER_EXTENSION = ".h";
	public static final String CPP_EXTENSION = ".cpp";
	public static final String APP_DIR = "app";
	public static final String LIBS_DIR = "libs";
	public static final String APP_INCLUDE_DIR = "app" + File.separator + "include";
	public static final String ALL_SRC_RELATIVE_FILE_PATH = "allSrcRelativeFilePath";
	public static final String HOST = "host";
	public static final String PORT = "port";
	public static final String BUILD_DEPENDENCY_SCRIPT = "build_dependencies.sh";
	public static final String CMAKELIST = "CMakeLists.txt";
	public static final String DYNAMIC_REST_API = "ModelRestAPI.cpp";
	public static final String DOCKER_COMPOSE_YML = "docker-compose.yml";
	public static final String DOCKER_FILE = "rest.Dockerfile";
	public static final String MODEL_MAIN_HEADER = "modelMain.h";
	public static final String STDAFX_HEADER = "stdafx.h";
	public static final String DEFAULT_WINX_DOCKER_DEMON = "tcp://localhost:2375";
	public static final String ACTIVE_STATUS = "ACTIVE";
	public static final String INACTIVE_STATUS = "INACTIVE";
	public static final String MODEL_CONFIGURE_FLAG = "configure";
	public static final String MODEL_VALIDATE_FLAG = "validate";
	public static final String MODEL_REGISTER_FLAG = "register";
	public static final String INPUTS = "inputmap";
	public static final String OUTPUTS = "outputmap";
	public static final String INPUTS_METADTA = "inputmetadata";
	public static final String OUTPUTS_METADATA = "outputmetadata";

	public static final String CPP_LANGUAGE = "cpp";
	public static final String PYTHON_LANGUAGE = "python";
	public static final String MODEL_REST_CREATOR_EXTN = "rest";
	public static final String PYTHON_EXTENSION = ".py"; 
	public static final String PYTHON_DYNAMIC_REST_API = "ModelController.py";
	public static final String PYTHON_MODULE_NAME = "module_name";
	public static final String PYTHON_MODULE_FUNCTION = "module_function";
	public static final String PYTHON_FLASK_APP= "python_flask_app";
	public static final String JAVA_LANGUAGE = "java";
	public static final String JAVA_EXTENSION = ".java"; 


}
