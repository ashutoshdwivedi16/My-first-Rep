package com.spglobal.ratings.rap;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;



@Service(RestCreatorConstants.JAVA_LANGUAGE)
public class JavaRuntimeImpl  {
	
	public Map<String, List<String>> getFiles(Set<String> listOfFiles) {
		Map<String, List<String>> filesList = new HashMap<String, List<String>>();
		List<String> javaFiles = listOfFiles.stream().filter(x -> x.endsWith(RestCreatorConstants.JAVA_EXTENSION))
				.collect(Collectors.toList());

		filesList.put("javaFiles", javaFiles);
		System.out.println("files list " + javaFiles.toString());

		return filesList;
	}
	
}
