import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.http.ResponseEntity;
@SpringBootApplication(scanBasePackages = "com.spglobal.ratings.rap")
@RestController
public class JavaRestCotroller {

@PostMapping("/hello")
	public ResponseEntity<Object> callJavaModel() {
//String test;
	
return	Application.message();		
	}

public static void main(String[] args) {
	SpringApplication.run(RestCreator.class, args);
}


}
