package com.spglobal.ratings.rap;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.stereotype.Service;

/*
 * @Serv public class Application {
 * 
 * public static void main(String[] args) {
 * SpringApplication.run(Application.class, args);
 * System.out.println("Java model runtime");
 * 
 * }
 * 
 * }
 */
@Service
//@EnableConfigurationProperties(ServiceProperties.class)
public class Application {


		public String message() {
		//return this.serviceProperties.getMessage();
		return "In model class";
	}
}
