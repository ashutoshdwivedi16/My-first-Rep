package com.spglobal.ratings.rap;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.Writer;
import java.nio.file.FileSystem;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Enumeration;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import freemarker.template.Configuration;
import freemarker.template.Template;
import freemarker.template.TemplateException;



@RestController(RestCreatorConstants.JAVA_LANGUAGE)
public class JavaRuntimeImpl  {
	
	@Value("${model.source.path}")
	String modelSourcePath;
	@Value("${model.destination.path}")
	String modelDestinationPath;
	private Configuration templateConfig;

	@Autowired
	public final void setTemplateConfig(Configuration templateConfig) {
		this.templateConfig = templateConfig;
	}
	@GetMapping("/dynamicrest")
	public  String generateController(Model model,String templateName)
	{
		Template template = null;
		templateName="JavaRestCotroller.ftl";
		try {
			template = templateConfig.getTemplate(templateName);
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		Writer file =null;
		model.addAttribute("fullyQualifiedName","com.spglobal.ratings.rap.Application");
		try {
			file= new FileWriter(new File(modelDestinationPath+"javarestapi/src/main/java/com/spglobal/ratings/rap/JavaRestCotroller.java"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			template.process(model, file);
		} catch (TemplateException | IOException e) {
			e.printStackTrace();
		}
		return templateName;
	}
	
	@GetMapping("/modelDir")
	public  String unZipmodel()
	{
	 try(ZipFile file = new ZipFile(modelSourcePath))
     {
         FileSystem fileSystem = FileSystems.getDefault();
         Enumeration<? extends ZipEntry> entries = file.entries();
        
         Path unZippedDirectory=fileSystem.getPath(modelDestinationPath);
         File directory = new File(modelDestinationPath);
         if(!directory.exists())
         {
         Files.createDirectory(unZippedDirectory);
         }
         while (entries.hasMoreElements()) 
         {
             ZipEntry entry = entries.nextElement();
             if (entry.isDirectory()) 
             {
            	 String modelDirName=entry.getName();
            	
                 Files.createDirectories(fileSystem.getPath(modelDestinationPath + modelDirName));
                 Files.createDirectories(fileSystem.getPath(modelDestinationPath+"javarestapi/src/main/java/com/spglobal/ratings/rap/"));
             } 
             else
             {
             
            	 InputStream is = file.getInputStream(entry);
                 BufferedInputStream bis = new BufferedInputStream(is);
                 String uncompressedFileName = modelDestinationPath + entry.getName();
                 Path uncompressedFilePath = fileSystem.getPath(uncompressedFileName);
           	 if(uncompressedFileName.contains("src") || uncompressedFileName.endsWith("xml")) {
                  Files.createFile(uncompressedFilePath);
                
                 FileOutputStream fileOutput = new FileOutputStream(uncompressedFileName);
                 while (bis.available() > 0) 
                 {
                     fileOutput.write(bis.read());
                 }
                 fileOutput.close();
                 System.out.println("Written :" + entry.getName());
             }
         }

         }
     }
     catch(IOException e)
     {
         e.printStackTrace();
     }
	return "model dir created";
 }

}

