package com.spglobal.ratings.rap;

import java.util.Locale;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import freemarker.template.TemplateExceptionHandler;

@Configuration
public class TemplateConfiguration {

	@Bean
	public freemarker.template.Configuration templateConfig() {
		freemarker.template.Configuration cfg = new freemarker.template.Configuration(
				freemarker.template.Configuration.VERSION_2_3_30);

		// Where do we load the templates from:
		cfg.setClassForTemplateLoading(TemplateConfiguration.class, "/templates/");

		// Some other recommended settings:
		// cfg.setIncompatibleImprovements(new Version(2, 3, 20));
		cfg.setDefaultEncoding("UTF-8");
		cfg.setLocale(Locale.US);
		cfg.setTemplateExceptionHandler(TemplateExceptionHandler.RETHROW_HANDLER);
		return cfg;
	}

}
